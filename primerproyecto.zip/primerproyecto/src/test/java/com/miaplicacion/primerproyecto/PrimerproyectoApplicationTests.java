package com.miaplicacion.primerproyecto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimerproyectoApplicationTests {

	@Test
	void contextLoads() {
	}

}
